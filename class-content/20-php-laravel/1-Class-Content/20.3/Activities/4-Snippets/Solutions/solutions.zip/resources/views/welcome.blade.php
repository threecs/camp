@extend('layout')

@section('title')
Laravel
@stop

@section('content')
  <h1>Welcome home.</h1>
@stop
