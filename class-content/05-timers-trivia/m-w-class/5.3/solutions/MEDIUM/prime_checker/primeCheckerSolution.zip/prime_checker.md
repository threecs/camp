# Prime Checker

## Do
Write a function which checks to see if a number is a prime number or not. Have it return `true` if it is, or `false` if it is not.

## Info
A Prime number is a number greater than one that can only be divided by one and itself.

[More info on Prime numbers](https://www.mathsisfun.com/prime_numbers.html)
